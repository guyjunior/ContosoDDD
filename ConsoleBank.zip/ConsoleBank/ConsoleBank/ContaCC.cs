﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleBank
{
    public class ContaCC : Conta
    {
    }
}
